Link repositório:
https://github.com/APedrosaUab/tarefa31b

Wireframe e Protótipo
Directório:
HTML5\wireframe_mockup

// Actualizado a 26 de novembro 2023 com base no acesso ao projecto

NOTA: De forma a reutilizar código, o ficheiro editar reutiliza o código do editar:
Caso não haja parametros, o botão passa a Adicionar em vez de Editar.
As mensagens também são personalizadas tendo isso em consideração.