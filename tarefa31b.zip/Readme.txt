Link repositório:
https://github.com/APedrosaUab/tarefa31b

Wireframe e Protótipo
Directório:
HTML5\wireframe_mockup